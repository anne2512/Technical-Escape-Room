

let initialCodeContainerState;

// Function to initialize the puzzle
function initializePuzzle() {
    // Get the initial state of the code container
    const codePuzzle = document.getElementById("codePuzzle");
    initialCodeContainerState = codePuzzle.innerHTML;
    console.log("noted")
}
 
document.addEventListener("DOMContentLoaded", function() {
    initializePuzzle();
});

// Function to handle drag event
function drag(event) {
    event.dataTransfer.setData("text", event.target.value);
}

// Function to handle drop event
// Function to handle drop event
function drop(event) {
    event.preventDefault();
    const data = event.dataTransfer.getData("text").trim();
    const codeContainer = document.getElementById("codeContainer");

    const inputElement = document.createElement("input");
    
    // Set input type to text
    inputElement.setAttribute("type", "text");
    console.log(data)
    
    // Set input value to the dropped data
    inputElement.setAttribute("value" , data);

    inputElement.className = "codePiece";
    inputElement.setAttribute("name", "codePiece");
    inputElement.setAttribute("readOnly",true)

    
    codeContainer.appendChild(inputElement);



    // Remove the dropped element from the code puzzle container
    const codePuzzle = document.getElementById("codePuzzle");
    const droppedElement = document.getElementById("codePiece" + data);
    if (droppedElement) {
        droppedElement.remove();
    } else {
        console.log("codePiece" + data)
        console.log("No element found");
        console.log({ data });
    }
}




// Function to allow drop
function allowDrop(event) {
    event.preventDefault();
}



// Function to reset the code container
function resetCodeContainer() {
    const codeContainer = document.getElementById("codeContainer");
    codeContainer.innerHTML = ''; // Clear the code container
}

// Function to undo the last dragged element
function undo() {
    const codeContainer = document.getElementById("codeContainer");
    const lastElement = codeContainer.lastChild;
    const codePuzzle = document.getElementById("codePuzzle");

    if (lastElement) {
        lastElement.remove();
        
        // Get the text content of the last element
        const dt = lastElement.textContent.trim();

        // Set the ID of the last element
        lastElement.id = "codePiece" + dt;
        lastElement.setAttribute("draggable","True")
        lastElement.setAttribute("ondragstart","drag(event)")

        // Append the last element to the code puzzle container
        codePuzzle.appendChild(lastElement);

    }

    

}

// Function to clear the code container
function clearCodeContainer() {

    const codeContainer = document.getElementById("codeContainer");
    codeContainer.innerHTML = "" ;

    const codePuzzle = document.getElementById("codePuzzle")
    codePuzzle.innerHTML = initialCodeContainerState ;


}


function confirm() {
    const codeContainer = document.getElementById("codeContainer");

    const elements = codeContainer.querySelectorAll('*');
    elements.forEach((element, index) => {
        element.id = "codePiece";
    });
}